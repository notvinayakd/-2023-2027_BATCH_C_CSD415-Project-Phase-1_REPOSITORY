TrustLC LaTeX source (IEEEtran conference format)
Compile: pdflatex main.tex  (run twice)  -- or upload the zip to Overleaf.
Requires IEEEtran.cls (included in TeX Live / Overleaf).
figures/workflow.jpg = Fig. 1, extracted from the original PDF.
Bibliography is inline (thebibliography), ordered to match the original numbering [1]-[12].
